const $ = (sel) => document.querySelector(sel);

const btnNew = $("#btnNew");
const btnContinue = $("#btnContinue");
const btnReset = $("#btnReset");
const storyEl = $("#story");
const choicesEl = $("#choices");

const SAVE_KEY = "twb_ch1_save_v1";

let storyData = window.STORY;
let state = null;
let currentNodeId = null;

const titleEl = $("#gameTitle");
if (titleEl && storyData?.meta?.title) {
  titleEl.textContent = storyData.meta.title;
}
document.title = storyData?.meta?.title ?? document.title;

if (!storyData) {
  console.error("STORY not found. Did you load storyData.js before game.js?");
}

if (!btnNew || !btnContinue || !btnReset || !storyEl || !choicesEl) {
  throw new Error("Missing required HTML elements. Check button ids and #story/#choices.");
}

btnNew.addEventListener("click", newGame);
btnContinue.addEventListener("click", continueGame);
btnReset.addEventListener("click", resetSave);

storyEl.textContent = "Press New to begin.";
choicesEl.innerHTML = "";

function newGame() {
  state = structuredClone(storyData.meta.variables);
  currentNodeId = storyData.meta.start;
  save();
  render();
}

function continueGame() {
  const raw = localStorage.getItem(SAVE_KEY);
  if (!raw) {
    storyEl.textContent = "No save found. Press New.";
    choicesEl.innerHTML = "";
    return;
  }
  const saveObj = JSON.parse(raw);
  state = saveObj.state;
  currentNodeId = saveObj.currentNodeId;
  render();
}

function resetSave() {
  localStorage.removeItem(SAVE_KEY);
  storyEl.textContent = "Save cleared.";
  choicesEl.innerHTML = "";
}

function save() {
  localStorage.setItem(SAVE_KEY, JSON.stringify({ state, currentNodeId }));
}

function render() {
  const node = storyData.nodes[currentNodeId];
  if (!node) {
    storyEl.innerHTML = `<p style="color:#f88">Missing node: ${currentNodeId}</p>`;
    choicesEl.innerHTML = "";
    return;
  }

  if (node.ending) {
    storyEl.innerHTML = `
      <h2>${escapeHtml(node.title ?? "ENDING")}</h2>
      ${node.text.map((t) => `<p>${escapeHtml(t)}</p>`).join("")}
    `;
    choicesEl.innerHTML = "";
    (node.choices ?? []).forEach(addChoice);
    save();
    return;
  }

  storyEl.innerHTML = (node.text ?? [])
    .map((t) => `<p>${escapeHtml(t)}</p>`)
    .join("");
  choicesEl.innerHTML = "";

  const available = (node.choices ?? []).filter(choicePassesConditions);

  const glitch = (state.clarity <= 50) || (state.dread >= 60) || (state.stampCount >= 2);
  const finalChoices = glitch ? shuffle([...available]) : available;

  finalChoices.forEach(addChoice);
  save();
}

function addChoice(choice) {
  const b = document.createElement("button");
  b.textContent = choice.label;

  b.addEventListener("click", () => {
    applyEffects(choice.effects);
    currentNodeId = choice.goto;
    render();
  });

  choicesEl.appendChild(b);
}

function applyEffects(effects = {}) {
  for (const [k, v] of Object.entries(effects)) {
    if (v === null) state[k] = null;
    else if (typeof v === "number") state[k] = (state[k] ?? 0) + v;
    else state[k] = v;
  }
}

function choicePassesConditions(choice) {
  const conds = choice.conditions ?? [];
  return conds.every((c) => {
    const val = state?.[c.var];
    if (c.op === "notnull") return val !== null && val !== undefined;
    if (c.op === "eq") return val === c.value;
    if (c.op === "gte") return Number(val) >= Number(c.value);
    if (c.op === "lte") return Number(val) <= Number(c.value);
    return true;
  });
}

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (m) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#39;"
  }[m]));
}
