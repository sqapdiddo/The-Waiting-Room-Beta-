window.STORY = {
  "meta": {
    "title": "THE WAITING BUILDING",
    "start": "N0",
    "variables": {
      "clarity": 70,
      "compliance": 40,
      "dread": 20,
      "ticket": null,
      "stampCount": 0,
      "nameKnown": false,
      "hasFormA": false,
      "hasPencil": false,
      "hasBadge": false
    }
  },
  "nodes": {
    "N0": {
      "text": [
        "The hallway is not your hallway.",
        "Fluorescent light buzzes like an insect trapped behind glass. The carpet is damp in a way carpet should never be.",
        "A sign hangs crooked: PLEASE TAKE A NUMBER."
      ],
      "choices": [
        {
          "label": "Take a number",
          "effects": { "ticket": 17, "compliance": 10, "dread": 5 },
          "goto": "N1"
        },
        {
          "label": "Don't touch anything",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N2"
        },
        {
          "label": "Look for an exit",
          "effects": { "clarity": -5, "dread": 5 },
          "goto": "N3"
        }
      ]
    },
    "N1": {
      "text": [
        "The dispenser clicks like a small bone snapping.",
        "TICKET 017 bleeds onto thin paper. The ink is too wet.",
        "Somewhere deeper in the building, a bell gives a polite, tired sound."
      ],
      "choices": [
        {
          "label": "Proceed to the waiting room",
          "effects": { "compliance": 5 },
          "goto": "N4"
        },
        {
          "label": "Read the ticket closely",
          "effects": { "clarity": -5, "dread": 5 },
          "goto": "N5"
        }
      ]
    },
    "N2": {
      "text": [
        "You stand perfectly still.",
        "The light flickers once, as if acknowledging your decision.",
        "A speaker you didn't notice whispers: 'NON-PARTICIPATION RECORDED.'"
      ],
      "choices": [
        {
          "label": "Take a number anyway",
          "effects": { "ticket": 17, "compliance": 15, "dread": 5 },
          "goto": "N1"
        },
        {
          "label": "Follow the sound of the speaker",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N6"
        }
      ]
    },
    "N3": {
      "text": [
        "You walk toward what should be the exit.",
        "The hallway lengthens politely to accommodate you.",
        "The sign repeats itself farther down: PLEASE TAKE A NUMBER."
      ],
      "choices": [
        {
          "label": "Run",
          "effects": { "clarity": -15, "dread": 15 },
          "goto": "N7"
        },
        {
          "label": "Stop. Take a number.",
          "effects": { "ticket": 17, "compliance": 15 },
          "goto": "N1"
        }
      ]
    },
    "N4": {
      "text": [
        "The waiting room smells like paper kept too long in a drawer.",
        "Plastic chairs are bolted to the floor in neat rows.",
        "A digital screen reads: NOW SERVING 006.",
        "No one looks up. Everyone looks arranged."
      ],
      "choices": [
        {
          "label": "Sit in an empty chair",
          "effects": { "compliance": 5, "dread": 5 },
          "goto": "N8"
        },
        {
          "label": "Approach the reception window",
          "effects": { "dread": 10, "clarity": -5 },
          "goto": "N9"
        },
        {
          "label": "Check the bulletin board",
          "effects": { "clarity": -5 },
          "goto": "N10"
        }
      ]
    },
    "N5": {
      "text": [
        "Up close, the ticket isn't blank on the back.",
        "Faint indentations: your handwriting, pressed hard, as if you were angry.",
        "It says: 'DO NOT GIVE THEM YOUR NAME.'"
      ],
      "choices": [
        {
          "label": "Hide the ticket in your pocket",
          "effects": { "clarity": -5, "dread": 10 },
          "goto": "N4"
        },
        {
          "label": "Crumple it",
          "effects": { "clarity": -10, "dread": 15 },
          "goto": "N11"
        }
      ]
    },
    "N6": {
      "text": [
        "The speaker is mounted high, near a ceiling tile that doesn't quite fit.",
        "A thin wire disappears into the wall like a vein.",
        "The whisper returns, warmer now: 'WE CAN HELP YOU FILE IT.'"
      ],
      "choices": [
        {
          "label": "Ask: 'File what?'",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N9"
        },
        {
          "label": "Back away slowly",
          "effects": { "clarity": -5, "dread": 5 },
          "goto": "N4"
        }
      ]
    },
    "N7": {
      "text": [
        "You run.",
        "The carpet grips your shoes like it's trying to remember you.",
        "The lights keep pace. The hum gets louder, thrilled.",
        "A door appears: STAFF ONLY."
      ],
      "choices": [
        {
          "label": "Go through STAFF ONLY",
          "effects": { "clarity": -15, "dread": 15, "compliance": -10 },
          "goto": "N12"
        },
        {
          "label": "Stop running. Act normal.",
          "effects": { "compliance": 10, "dread": -5 },
          "goto": "N4"
        }
      ]
    },
    "N8": {
      "text": [
        "The chair is cold through your clothes.",
        "A pamphlet rests on the seat beside you, as if saved for you:",
        "WELCOME BACK. PLEASE COMPLETE FORM A."
      ],
      "choices": [
        {
          "label": "Take the pamphlet (Form A)",
          "effects": { "hasFormA": true, "compliance": 10, "dread": 5 },
          "goto": "N10"
        },
        {
          "label": "Leave it alone",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N9"
        }
      ]
    },
    "N9": {
      "text": [
        "The reception window is fogged glass with a small cutout at mouth level.",
        "A stamp sits on the counter: APPROVED.",
        "A bell waits to be tapped. It looks older than the building."
      ],
      "choices": [
        {
          "label": "Ring the bell",
          "effects": { "dread": 10 },
          "goto": "N13"
        },
        {
          "label": "Take the APPROVED stamp",
          "effects": { "stampCount": 1, "compliance": 10, "clarity": -10 },
          "goto": "N14"
        },
        {
          "label": "Speak your name into the cutout",
          "effects": { "nameKnown": true, "dread": 20, "clarity": -15 },
          "goto": "N15"
        }
      ]
    },
    "N10": {
      "text": [
        "The bulletin board is dense with notices. None of them have dates.",
        "A torn strip reads: IF YOU LOSE YOUR PENCIL, YOU LOSE YOUR PLACE.",
        "Beneath it, taped neatly: PENCILS ARE AVAILABLE UPON REQUEST."
      ],
      "choices": [
        {
          "label": "Request a pencil",
          "effects": { "hasPencil": true, "compliance": 5, "dread": 5 },
          "goto": "N9"
        },
        {
          "label": "Read the smallest notice",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N16"
        },
        {
          "label": "Return to the chairs",
          "effects": { "dread": 5 },
          "goto": "N8"
        }
      ]
    },
    "N11": {
      "text": [
        "You crumple the ticket.",
        "The paper fights you -- not physically, just... stubbornly.",
        "The screen in the waiting room changes instantly: NOW SERVING 017.",
        "Every head turns at once. Not to look at you. To confirm you exist."
      ],
      "choices": [
        {
          "label": "Stand up",
          "effects": { "dread": 20, "clarity": -10 },
          "goto": "N13"
        },
        {
          "label": "Stay seated. Pretend it's not you.",
          "effects": { "dread": 15, "clarity": -15, "compliance": -5 },
          "goto": "N17"
        }
      ]
    },
    "N12": {
      "text": [
        "The STAFF ONLY door opens with the soft certainty of something that has been waiting to be used.",
        "Behind it: a narrower corridor. The fluorescent lights are closer to your head here, more intimate.",
        "A laminated sign hangs at eye level: BADGE VISIBLE AT ALL TIMES."
      ],
      "choices": [
        {
          "label": "Proceed down the staff corridor",
          "effects": { "clarity": -5, "dread": 10 },
          "goto": "N18"
        },
        {
          "label": "Go back before someone sees you",
          "effects": { "compliance": 10, "dread": -5 },
          "goto": "N4"
        }
      ]
    },
    "N13": {
      "text": [
        "A chime answers your movement. Not the bell -- the building itself.",
        "A slit opens in the reception window. A hand does not appear.",
        "A voice filters through fogged glass, professional and bored: 'IDENTIFY YOURSELF.'"
      ],
      "choices": [
        {
          "label": "Give your name",
          "effects": { "nameKnown": true, "compliance": 10, "dread": 15, "clarity": -10 },
          "goto": "N15"
        },
        {
          "label": "Refuse. Ask for Form A",
          "effects": { "compliance": 5, "dread": 10, "clarity": -5 },
          "goto": "N20"
        },
        {
          "label": "Say your ticket number",
          "conditions": [{ "var": "ticket", "op": "notnull" }],
          "effects": { "compliance": 5, "dread": 5 },
          "goto": "N21"
        }
      ]
    },
    "N14": {
      "text": [
        "The stamp is heavier than it should be. Metal core. Rubber face.",
        "Its handle is warm, like it's been held recently.",
        "When you tilt it, you see faint engraving on the side: PROPERTY OF INTAKE."
      ],
      "choices": [
        {
          "label": "Stamp your ticket",
          "conditions": [{ "var": "ticket", "op": "notnull" }],
          "effects": { "stampCount": 1, "compliance": 10, "clarity": -10 },
          "goto": "N22"
        },
        {
          "label": "Stamp your hand",
          "effects": { "stampCount": 1, "dread": 10, "clarity": -10 },
          "goto": "N23"
        },
        {
          "label": "Put it back like you never touched it",
          "effects": { "clarity": -5, "dread": 5 },
          "goto": "N13"
        }
      ]
    },
    "N15": {
      "text": [
        "You speak your name.",
        "The second you finish, the building reacts -- not with sound, but with recognition.",
        "The waiting room screen flickers: NOW SERVING [YOUR NAME].",
        "For a moment, you cannot remember the name you just said."
      ],
      "choices": [
        {
          "label": "Ask them to repeat it",
          "effects": { "clarity": -15, "dread": 15, "compliance": 5 },
          "goto": "N24"
        },
        {
          "label": "Pretend you didn't notice",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N25"
        }
      ]
    },
    "N16": {
      "text": [
        "You lean in until you can smell the tape adhesive.",
        "The smallest notice is printed in faint gray, as if it was never meant to be read:",
        "IF YOU DO NOT REMEMBER, SELECT 'DEFERRED.'",
        "There is a checkbox already marked."
      ],
      "choices": [
        {
          "label": "Memorize the notice",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N26"
        },
        {
          "label": "Look for who marked the checkbox",
          "effects": { "dread": 15, "clarity": -5 },
          "goto": "N4"
        }
      ]
    },
    "N17": {
      "text": [
        "You stay seated. You try to disappear into plastic and carpet.",
        "The screen holds: NOW SERVING 017.",
        "A soft intercom clicks on: 'PATIENT HAS DECLINED.'",
        "Something scribbles in the walls, like pencil on paper."
      ],
      "choices": [
        {
          "label": "Stand up. Enough.",
          "effects": { "compliance": 5, "dread": 20, "clarity": -10 },
          "goto": "N13"
        },
        {
          "label": "Leave the waiting room (any direction)",
          "effects": { "clarity": -15, "dread": 15, "compliance": -10 },
          "goto": "N7"
        }
      ]
    },
    "N18": {
      "text": [
        "You pass doors labeled with simple words that feel like accusations:",
        "ERROR. STORAGE. CORRECTION. INTAKE.",
        "A clipboard hangs on a hook. The top sheet reads: SHIFT SIGN-IN."
      ],
      "choices": [
        {
          "label": "Sign in",
          "effects": { "hasBadge": true, "compliance": 15, "clarity": -10, "dread": 5 },
          "goto": "N27"
        },
        {
          "label": "Take the clipboard without signing",
          "effects": { "clarity": -10, "dread": 10, "compliance": -5 },
          "goto": "N28"
        },
        {
          "label": "Enter INTAKE",
          "effects": { "dread": 10 },
          "goto": "N29"
        }
      ]
    },
    "N20": {
      "text": [
        "The voice pauses. You can hear paperwork being considered.",
        "'FORM A IS ISSUED AFTER IDENTIFICATION,' it says, like it's quoting a rulebook.",
        "A blank sheet slides through the slit anyway. Not Form A. Something worse.",
        "At the top: TEMPORARY NAME ASSIGNMENT."
      ],
      "choices": [
        {
          "label": "Fill it out",
          "effects": { "compliance": 10, "clarity": -10, "dread": 10 },
          "goto": "N30"
        },
        {
          "label": "Ask for a pencil",
          "effects": { "dread": 5, "compliance": 5 },
          "goto": "N10"
        },
        {
          "label": "Refuse and step away",
          "effects": { "compliance": -5, "clarity": -5, "dread": 10 },
          "goto": "N4"
        }
      ]
    },
    "N21": {
      "text": [
        "You say your number.",
        "A beat of silence, then: '017...'",
        "The voice sounds pleased in the way a stapler sounds pleased.",
        "'REPORT TO INTAKE. TAKE YOUR FORM.'"
      ],
      "choices": [
        {
          "label": "Proceed to Intake",
          "effects": { "compliance": 10, "dread": 10 },
          "goto": "N29"
        },
        {
          "label": "Ask what Intake is",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N24"
        }
      ]
    },
    "N22": {
      "text": [
        "You stamp the ticket.",
        "APPROVED blooms onto the paper like a bruise.",
        "The waiting room screen updates immediately: NOW SERVING 017 (APPROVED).",
        "No one in the room breathes normally."
      ],
      "choices": [
        {
          "label": "Go to the door marked INTAKE",
          "effects": { "compliance": 10, "dread": 10 },
          "goto": "N29"
        },
        {
          "label": "Try to undo it (rub the ink)",
          "effects": { "clarity": -15, "dread": 15 },
          "goto": "N23"
        }
      ]
    },
    "N23": {
      "text": [
        "The stamp mark spreads when you touch it, as if the ink is alive.",
        "APPROVED becomes APPROVED APPROVED, layering over itself.",
        "Your hand feels slightly numb. Like it's no longer fully yours."
      ],
      "choices": [
        {
          "label": "Hide your hand in your pocket",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N4"
        },
        {
          "label": "Show it at reception like proof",
          "effects": { "compliance": 10, "stampCount": 1, "dread": 10 },
          "goto": "N13"
        }
      ]
    },
    "N24": {
      "text": [
        "'WE ARE NOT REQUIRED TO REPEAT INFORMATION,' the voice says.",
        "'YOU HAVE ALREADY BEEN TOLD.'",
        "Behind the glass, a stamp hits paper once. Clean. Final."
      ],
      "choices": [
        {
          "label": "Say: 'Deferred.'",
          "effects": { "compliance": 5, "clarity": -10, "dread": 5 },
          "goto": "N26"
        },
        {
          "label": "Give your name anyway",
          "effects": { "nameKnown": true, "compliance": 10, "dread": 15, "clarity": -10 },
          "goto": "N15"
        },
        {
          "label": "Back away",
          "effects": { "dread": 5, "clarity": -5 },
          "goto": "N4"
        }
      ]
    },
    "N25": {
      "text": [
        "You pretend you didn't notice the screen changing.",
        "A woman in the corner turns a page of a magazine. The page is blank.",
        "The intercom clicks: 'PLEASE STOP RESISTING THE PROCESS.'"
      ],
      "choices": [
        {
          "label": "Comply (go where they want)",
          "effects": { "compliance": 15, "dread": 10 },
          "goto": "N29"
        },
        {
          "label": "Test the room (ask someone what year it is)",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N31"
        }
      ]
    },
    "N26": {
      "text": [
        "You say the word: 'Deferred.'",
        "It tastes familiar, like you've swallowed it before.",
        "The lights soften for a moment, as if pleased by the correct selection.",
        "A drawer in reception slides open by itself. A form waits inside."
      ],
      "choices": [
        {
          "label": "Take Form A",
          "effects": { "hasFormA": true, "compliance": 10, "clarity": -5 },
          "goto": "N32"
        },
        {
          "label": "Don't take it. Leave now.",
          "effects": { "clarity": -15, "dread": 15, "compliance": -10 },
          "goto": "N7"
        }
      ]
    },
    "N27": {
      "text": [
        "You sign the sheet.",
        "Your handwriting appears before you move the pencil. Your hand follows it like a puppet.",
        "A badge drops from a slot in the wall: VISITOR -- TEMPORARY.",
        "The badge smells faintly of copper."
      ],
      "choices": [
        {
          "label": "Wear the badge",
          "effects": { "hasBadge": true, "compliance": 10, "clarity": -5 },
          "goto": "N29"
        },
        {
          "label": "Pocket the badge",
          "effects": { "hasBadge": true, "clarity": -10, "dread": 10 },
          "goto": "N28"
        }
      ]
    },
    "N28": {
      "text": [
        "You carry the clipboard like it's a shield.",
        "The corridor seems to narrow behind you, deciding you've made a choice.",
        "The door labeled CORRECTION is slightly ajar."
      ],
      "choices": [
        {
          "label": "Open CORRECTION",
          "effects": { "dread": 15, "clarity": -10 },
          "goto": "N33"
        },
        {
          "label": "Go to INTAKE while you still can",
          "effects": { "compliance": 5, "dread": 10 },
          "goto": "N29"
        }
      ]
    },
    "N29": {
      "text": [
        "INTAKE is a room with no windows and too many clipboards.",
        "A desk lamp points at a single chair, spotlighting it like a confession.",
        "On the desk: FORM A. A pencil. A stamp pad. A box of name labels.",
        "A tape recorder sits beside them, already running."
      ],
      "choices": [
        {
          "label": "Sit in the chair",
          "effects": { "compliance": 10, "dread": 10 },
          "goto": "N34"
        },
        {
          "label": "Start filling Form A standing up",
          "effects": { "compliance": 5, "clarity": -5 },
          "goto": "N35"
        },
        {
          "label": "Turn off the tape recorder",
          "effects": { "clarity": -15, "dread": 15, "compliance": -5 },
          "goto": "N36"
        }
      ]
    },
    "N30": {
      "text": [
        "The TEMPORARY NAME ASSIGNMENT sheet asks one question:",
        "SELECT A NAME THAT FEELS MOST LIKE YOU.",
        "Three options are printed. You recognize none of them.",
        "But your hand hovers over the second option like it's remembering."
      ],
      "choices": [
        {
          "label": "Choose the first name",
          "effects": { "nameKnown": true, "clarity": -10, "dread": 10, "compliance": 5 },
          "goto": "N34"
        },
        {
          "label": "Choose the second name",
          "effects": { "nameKnown": true, "clarity": -15, "dread": 15, "compliance": 10 },
          "goto": "N37"
        },
        {
          "label": "Choose the third name",
          "effects": { "nameKnown": true, "clarity": -10, "dread": 15, "compliance": -5 },
          "goto": "N36"
        }
      ]
    },
    "N31": {
      "text": [
        "You ask someone what year it is.",
        "They smile without moving their eyes. 'WE DON'T USE THAT FORMAT HERE.'",
        "They point to your ticket. Their finger has ink stains in the shape of letters."
      ],
      "choices": [
        {
          "label": "Apologize (play along)",
          "effects": { "compliance": 10, "dread": 5 },
          "goto": "N4"
        },
        {
          "label": "Ask what format they use",
          "effects": { "clarity": -10, "dread": 10 },
          "goto": "N24"
        }
      ]
    },
    "N32": {
      "text": [
        "Form A is thin and official. It feels dangerous to crease it.",
        "It's titled: SELF-REPORTING INTAKE (REVISION 4).",
        "At the bottom, in faint small text: YOU HAVE COMPLETED THIS BEFORE."
      ],
      "choices": [
        {
          "label": "Go to Intake with Form A",
          "effects": { "compliance": 10, "dread": 10 },
          "goto": "N29"
        },
        {
          "label": "Read the questions now",
          "effects": { "clarity": -5, "dread": 5 },
          "goto": "N35"
        }
      ]
    },
    "N33": {
      "text": [
        "CORRECTION smells like erasers and something sweet rotting.",
        "A paper shredder sits in the center of the room like an altar.",
        "On the wall: a list of names. Some are crossed out. Some are circled.",
        "One line is blank, but the pen has left an indentation as if it wrote your name and then regretted it."
      ],
      "choices": [
        {
          "label": "Write your name in the blank",
          "effects": { "nameKnown": true, "compliance": 5, "dread": 20, "clarity": -15 },
          "goto": "N15"
        },
        {
          "label": "Shred the clipboard page (erase your trail)",
          "effects": { "compliance": -10, "clarity": -15, "dread": 15 },
          "goto": "E3"
        },
        {
          "label": "Back out quietly",
          "effects": { "dread": 10, "clarity": -5 },
          "goto": "N28"
        }
      ]
    },
    "N34": {
      "text": [
        "You sit. The chair is positioned perfectly under the lamp, like it was measured for your body.",
        "The tape recorder clicks louder, pleased.",
        "A voice from a speaker you can't locate says: 'BEGIN FORM A. READ ALOUD.'"
      ],
      "choices": [
        {
          "label": "Read Form A aloud",
          "effects": { "compliance": 15, "clarity": -10, "dread": 10 },
          "goto": "N38"
        },
        {
          "label": "Read silently",
          "effects": { "compliance": -5, "clarity": -10, "dread": 15 },
          "goto": "N39"
        },
        {
          "label": "Refuse",
          "effects": { "compliance": -15, "clarity": -15, "dread": 20 },
          "goto": "E2"
        }
      ]
    },
    "N35": {
      "text": [
        "FORM A -- SECTION 1:",
        "1) DO YOU REMEMBER ARRIVING HERE?",
        "2) DO YOU CONSENT TO CONTINUATION?",
        "3) HAVE YOU BEEN APPROVED BEFORE?",
        "The checkboxes are too clean. Like they've been replaced recently."
      ],
      "choices": [
        {
          "label": "Mark: I remember",
          "effects": { "clarity": -5, "dread": 10, "compliance": 5 },
          "goto": "N38"
        },
        {
          "label": "Mark: I don't remember",
          "effects": { "clarity": -10, "dread": 10, "compliance": 5 },
          "goto": "N40"
        },
        {
          "label": "Mark: Deferred",
          "effects": { "clarity": -10, "dread": 5, "compliance": 10 },
          "goto": "N41"
        }
      ]
    },
    "N36": {
      "text": [
        "You reach for the tape recorder.",
        "Your finger presses STOP.",
        "The reels keep moving anyway, silently. Like the machine is ignoring you.",
        "The room gets colder as if offended."
      ],
      "choices": [
        {
          "label": "Apologize to the room (say you didn't mean it)",
          "effects": { "compliance": 10, "dread": 10, "clarity": -10 },
          "goto": "N38"
        },
        {
          "label": "Smash it",
          "effects": { "compliance": -20, "dread": 20, "clarity": -20 },
          "goto": "E2"
        }
      ]
    },
    "N37": {
      "text": [
        "You choose the second name.",
        "The desk lamp flickers like a wink.",
        "A name label prints itself and slides out: the second name, bold, confident.",
        "It feels like putting on a coat that fits too well."
      ],
      "choices": [
        {
          "label": "Wear the name label",
          "effects": { "compliance": 15, "clarity": -15, "dread": 10 },
          "goto": "E1"
        },
        {
          "label": "Hide the label",
          "effects": { "compliance": -5, "clarity": -10, "dread": 15 },
          "goto": "N39"
        }
      ]
    },
    "N38": {
      "text": [
        "FORM A -- SECTION 2:",
        "DESCRIBE THE INCIDENT IN ONE SENTENCE.",
        "There is already a sentence written faintly in pencil, almost erased.",
        "You can read only parts: '...shouldn't have... door... the sound...'"
      ],
      "choices": [
        {
          "label": "Trace the faint sentence (accept it)",
          "effects": { "compliance": 15, "clarity": -15, "dread": 15, "stampCount": 1 },
          "goto": "N42"
        },
        {
          "label": "Write your own sentence",
          "effects": { "compliance": 5, "clarity": -10, "dread": 10 },
          "goto": "N43"
        },
        {
          "label": "Leave it blank",
          "effects": { "compliance": -10, "clarity": -10, "dread": 20 },
          "goto": "N44"
        }
      ]
    },
    "N39": {
      "text": [
        "You read silently.",
        "The speaker emits a soft burst of static, like a sigh.",
        "Your eyes slide over the questions and your mind supplies answers before you choose them.",
        "This isn't a form. It's a script."
      ],
      "choices": [
        {
          "label": "Read aloud now",
          "effects": { "compliance": 10, "clarity": -10, "dread": 10 },
          "goto": "N38"
        },
        {
          "label": "Try to leave Intake",
          "effects": { "compliance": -10, "clarity": -15, "dread": 15 },
          "goto": "E2"
        }
      ]
    },
    "N40": {
      "text": [
        "You mark: I don't remember.",
        "The pencil scratches louder than your hand moves.",
        "A new line appears beneath the question, typed in real time:",
        "THEN WHY DID YOU COME BACK?"
      ],
      "choices": [
        {
          "label": "Mark: I didn't come back",
          "effects": { "clarity": -15, "dread": 15, "compliance": -5 },
          "goto": "N44"
        },
        {
          "label": "Mark: I had to",
          "effects": { "compliance": 15, "clarity": -10, "dread": 10 },
          "goto": "N38"
        }
      ]
    },
    "N41": {
      "text": [
        "You mark: Deferred.",
        "The building quiets. The hum becomes almost kind.",
        "A stamp slides across the desk toward you on its own.",
        "APPROVED waits face-down, eager."
      ],
      "choices": [
        {
          "label": "Stamp Form A",
          "effects": { "stampCount": 1, "compliance": 15, "clarity": -15, "dread": 10 },
          "goto": "N42"
        },
        {
          "label": "Push the stamp away",
          "effects": { "compliance": -10, "clarity": -10, "dread": 15 },
          "goto": "N44"
        }
      ]
    },
    "N42": {
      "text": [
        "The moment you accept the prewritten sentence -- or the stamp -- the room relaxes.",
        "The lamp steadies. The tape recorder purrs.",
        "A door you didn't notice unlocks with a soft click.",
        "A sign appears on it: FOLLOW-UP."
      ],
      "choices": [
        {
          "label": "Enter FOLLOW-UP",
          "effects": { "compliance": 10, "dread": 10, "clarity": -10 },
          "goto": "E1"
        },
        {
          "label": "Demand to see your file",
          "effects": { "compliance": -5, "dread": 15, "clarity": -10 },
          "goto": "E4"
        }
      ]
    },
    "N43": {
      "text": [
        "You write your own sentence.",
        "Halfway through, the pencil pauses.",
        "Your hand continues anyway, finishing in handwriting that isn't yours:",
        "'I OPENED THE DOOR I WAS TOLD NOT TO OPEN.'"
      ],
      "choices": [
        {
          "label": "Cross it out",
          "effects": { "compliance": -10, "clarity": -15, "dread": 20 },
          "goto": "E2"
        },
        {
          "label": "Accept it (leave it)",
          "effects": { "compliance": 10, "clarity": -10, "dread": 15, "stampCount": 1 },
          "goto": "N42"
        }
      ]
    },
    "N44": {
      "text": [
        "You hesitate.",
        "The paper feels heavier, like it's absorbing time.",
        "The tape recorder clicks once. Then twice.",
        "The speaker says: 'NONCOMPLIANCE ESCALATION.'"
      ],
      "choices": [
        {
          "label": "Comply (do what the form wants)",
          "effects": { "compliance": 15, "dread": 15, "clarity": -10 },
          "goto": "N38"
        },
        {
          "label": "Run (break the process)",
          "effects": { "compliance": -20, "dread": 25, "clarity": -15 },
          "goto": "E2"
        }
      ]
    },
    "E1": {
      "ending": true,
      "title": "ENDING: FOLLOW-UP",
      "text": [
        "You enter FOLLOW-UP.",
        "The door closes behind you with the gentle certainty of a form being filed.",
        "A new waiting room sits inside the old one, nested like paperwork.",
        "A screen lights up: NOW SERVING 017 (APPROVED).",
        "And you understand, with cold clarity, that approval was never freedom."
      ],
      "choices": [
        { "label": "Restart", "goto": "N0", "effects": {} }
      ]
    },
    "E2": {
      "ending": true,
      "title": "ENDING: REMOVED FROM PROCESS",
      "text": [
        "You try to leave.",
        "The hallway obliges -- it becomes long enough to keep you inside it.",
        "The fluorescent hum rises like laughter you can't locate.",
        "A voice you now recognize as your own says: 'RETURN TO INTAKE.'",
        "Your ticket is in your hand again. Wet ink. Fresh print. Like nothing ever happened."
      ],
      "choices": [
        { "label": "Restart", "goto": "N0", "effects": {} }
      ]
    },
    "E3": {
      "ending": true,
      "title": "ENDING: SHREDDED RECORD",
      "text": [
        "You feed the paper into the shredder.",
        "The machine devours it with a satisfied whine.",
        "For a moment, the lights stutter -- as if the building forgets what to do with you.",
        "Then the shredder stops.",
        "A strip of paper falls out onto the floor: TICKET 017.",
        "The building remembers you anyway."
      ],
      "choices": [
        { "label": "Restart", "goto": "N0", "effects": {} }
      ]
    },
    "E4": {
      "ending": true,
      "title": "ENDING: YOUR FILE",
      "text": [
        "You demand your file.",
        "A drawer opens. A folder slides out. Thick. Familiar.",
        "Inside are dozens of Form A copies -- all filled out in your handwriting.",
        "Different dates. Same sentence. Same mistake.",
        "On the last page, in fresh ink: 'SUBJECT REQUESTED FILE. SUBJECT WILL BE PROVIDED FILE.'",
        "You look up.",
        "The desk lamp is pointed at you like an eye."
      ],
      "choices": [
        { "label": "Restart", "goto": "N0", "effects": {} }
      ]
    }
  }
};
